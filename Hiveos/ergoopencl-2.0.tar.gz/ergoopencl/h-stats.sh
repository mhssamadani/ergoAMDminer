#!/usr/bin/env bash

. $MINER_DIR/$CUSTOM_MINER/h-manifest.conf

stats_raw=`curl --connect-timeout 2 --max-time 5 --silent --noproxy '*' http://127.0.0.1:36207`
len=`echo $stats_raw | jq '.hs | length'`
len_i=`bc -l <<< $len-1`
total=0
for num in $(seq 0 $len_i)
do
	hs=`echo $stats_raw | jq --arg i $num '.hs[$i | tonumber]'`
	#echo $hs
	total=`echo $total + $hs | bc`
	#total=$((total+`echo $stats_raw | jq --arg i $num '.hs[$i | tonumber]'`))
done

#echo $total

khs=`bc -l <<< $total*1000`
stats=$stats_raw

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"



#stats=`jq -n --arg hs $khs --argjson hs_units "$hs_units" --argjson uptime "$uptime" --argjson ar "$ar" --argjson algo "$algo" '.[$hs] | .[$hs_units] | .[$uptime] | .[$ar] | .[$algo] '
